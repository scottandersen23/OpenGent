import { z } from 'zod';

export const roleOptions = [
  'Founder / CEO',
  'CTO / VP Engineering',
  'Head of Data / Analytics',
  'Data Engineer / Analyst',
  'Other'
] as const;

export const challengeOptions = [
  'Broken or unreliable data pipelines',
  'Metrics that do not match across dashboards',
  'Data quality issues',
  'Slow or reactive reporting',
  'We want better monitoring for our data stack'
] as const;

export const toolOptions = [
  'Snowflake',
  'Postgres',
  'BigQuery',
  'dbt',
  'Airflow',
  'Fivetran',
  'Looker',
  'Tableau',
  'Other'
] as const;

export const leadSchema = z.object({
  name: z.string().min(2).max(100),
  email: z.string().email(),
  company: z.string().min(2).max(120),
  role: z.enum(roleOptions),
  challenges: z.array(z.enum(challengeOptions)).min(1).max(challengeOptions.length),
  tools: z.array(z.enum(toolOptions)).min(1).max(toolOptions.length)
});

export type LeadInput = z.infer<typeof leadSchema>;
