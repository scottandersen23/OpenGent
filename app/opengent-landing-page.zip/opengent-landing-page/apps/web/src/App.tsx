import { LeadForm } from './components/LeadForm';

function App() {
  return (
    <div className="page-shell">
      <header className="site-header">
        <div className="brand-lockup">
          <img src="/logo.png" alt="OpenGent logo" className="brand-logo" />
          <div>
            <p className="eyebrow">OpenGent</p>
            <p className="brand-subtitle">Autonomous intelligence for modern data stacks</p>
          </div>
        </div>
        <a href="#waitlist" className="ghost-button">
          Get early access
        </a>
      </header>

      <main>
        <section className="hero">
          <div className="hero-copy">
            <p className="eyebrow">AI agents for SaaS analytics infrastructure</p>
            <h1>Monitor your data stack before broken pipelines break the business.</h1>
            <p className="hero-text">
              OpenGent deploys AI agents that continuously monitor pipelines, metrics, and business
              signals so your team can trust its numbers and move faster.
            </p>
            <div className="hero-actions">
              <a href="#waitlist" className="primary-button">
                Join the early access list
              </a>
              <a href="#how-it-works" className="secondary-button">
                See how it works
              </a>
            </div>
            <div className="hero-proof">
              <span>Pipeline visibility</span>
              <span>Revenue anomaly detection</span>
              <span>Executive-ready alerts</span>
            </div>
          </div>

          <div className="hero-panel">
            <div className="metric-card large">
              <p>Data stack intelligence</p>
              <strong>Continuous monitoring</strong>
              <span>Pipeline freshness · metric drift · anomaly signals</span>
            </div>
            <div className="metric-row">
              <div className="metric-card">
                <p>Engineering load</p>
                <strong>↓ manual debugging</strong>
              </div>
              <div className="metric-card">
                <p>Decision speed</p>
                <strong>↑ trusted insights</strong>
              </div>
            </div>
          </div>
        </section>

        <section className="section" id="how-it-works">
          <div className="section-heading">
            <p className="eyebrow">How it works</p>
            <h2>OpenGent adds an intelligence layer on top of your existing stack.</h2>
          </div>
          <div className="cards three-up">
            <article className="card">
              <h3>Observe the stack</h3>
              <p>
                Connect to your warehouse and monitor pipeline freshness, schema changes, volume
                shifts, and data quality issues.
              </p>
            </article>
            <article className="card">
              <h3>Explain the impact</h3>
              <p>
                Translate anomalies into clear business context so leadership understands what
                changed and why it matters.
              </p>
            </article>
            <article className="card">
              <h3>Act faster</h3>
              <p>
                Route the right signals to the right teams with proactive alerts instead of waiting
                for dashboards to go stale.
              </p>
            </article>
          </div>
        </section>

        <section className="section split-section">
          <div>
            <p className="eyebrow">Why teams buy</p>
            <h2>Reduce costly data fires and protect decision quality.</h2>
            <p className="section-copy">
              Most SaaS teams still discover broken data after the fact. OpenGent helps teams catch
              issues early, cut debugging time, and keep strategic metrics trustworthy.
            </p>
          </div>
          <div className="cards stacked">
            <article className="card emphasis">
              <h3>Save engineering time</h3>
              <p>Reduce reactive debugging across pipelines, dashboards, and reporting workflows.</p>
            </article>
            <article className="card emphasis">
              <h3>Protect revenue reporting</h3>
              <p>Catch silent ingestion failures and business anomalies before they distort metrics.</p>
            </article>
            <article className="card emphasis">
              <h3>Move with confidence</h3>
              <p>Give leadership faster answers with automated context and decision-ready alerts.</p>
            </article>
          </div>
        </section>

        <section className="section waitlist-section" id="waitlist">
          <div className="section-heading narrow">
            <p className="eyebrow">Get early access to OpenGent</p>
            <h2>Join the list for launch updates and pilot opportunities.</h2>
            <p className="section-copy">
              Tell us about your role, current data challenges, and stack. We’ll use it to prioritize
              early pilot access and product updates.
            </p>
          </div>
          <LeadForm />
        </section>
      </main>
    </div>
  );
}

export default App;
