import { FormEvent, useMemo, useState } from 'react';
import { leadSchema, roleOptions, challengeOptions, toolOptions } from '@opengent/shared';

const API_URL = import.meta.env.VITE_API_URL ?? 'http://localhost:8080';

type FormState = {
  name: string;
  email: string;
  company: string;
  role: string;
  challenges: string[];
  tools: string[];
};

const initialState: FormState = {
  name: '',
  email: '',
  company: '',
  role: '',
  challenges: [],
  tools: []
};

export function LeadForm() {
  const [form, setForm] = useState<FormState>(initialState);
  const [error, setError] = useState<string>('');
  const [success, setSuccess] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const canSubmit = useMemo(() => !isSubmitting, [isSubmitting]);

  function toggleArrayField(field: 'challenges' | 'tools', value: string) {
    setForm((current) => {
      const exists = current[field].includes(value);
      return {
        ...current,
        [field]: exists
          ? current[field].filter((item) => item !== value)
          : [...current[field], value]
      };
    });
  }

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError('');
    setSuccess('');

    const payload = leadSchema.safeParse(form);
    if (!payload.success) {
      setError('Please complete all required fields before submitting.');
      return;
    }

    try {
      setIsSubmitting(true);
      const response = await fetch(`${API_URL}/api/leads`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload.data)
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message ?? 'Submission failed.');
      }

      setSuccess('Thanks — you have been added to the OpenGent early access list.');
      setForm(initialState);
    } catch (submissionError) {
      setError(
        submissionError instanceof Error
          ? submissionError.message
          : 'Something went wrong. Please try again.'
      );
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <form className="lead-form" onSubmit={onSubmit} noValidate>
      <div className="form-grid">
        <label>
          <span>Name</span>
          <input
            value={form.name}
            onChange={(event) => setForm({ ...form, name: event.target.value })}
            placeholder="Jane Smith"
            required
          />
        </label>
        <label>
          <span>Email</span>
          <input
            type="email"
            value={form.email}
            onChange={(event) => setForm({ ...form, email: event.target.value })}
            placeholder="jane@company.com"
            required
          />
        </label>
        <label>
          <span>Company</span>
          <input
            value={form.company}
            onChange={(event) => setForm({ ...form, company: event.target.value })}
            placeholder="Acme SaaS"
            required
          />
        </label>
        <label>
          <span>What best describes your role?</span>
          <select
            value={form.role}
            onChange={(event) => setForm({ ...form, role: event.target.value })}
            required
          >
            <option value="">Select one</option>
            {roleOptions.map((option) => (
              <option key={option} value={option}>
                {option}
              </option>
            ))}
          </select>
        </label>
      </div>

      <fieldset>
        <legend>What data challenges are you currently facing?</legend>
        <div className="chip-grid">
          {challengeOptions.map((option) => (
            <button
              key={option}
              type="button"
              className={form.challenges.includes(option) ? 'chip active' : 'chip'}
              onClick={() => toggleArrayField('challenges', option)}
            >
              {option}
            </button>
          ))}
        </div>
      </fieldset>

      <fieldset>
        <legend>What tools are in your data stack?</legend>
        <div className="chip-grid">
          {toolOptions.map((option) => (
            <button
              key={option}
              type="button"
              className={form.tools.includes(option) ? 'chip active' : 'chip'}
              onClick={() => toggleArrayField('tools', option)}
            >
              {option}
            </button>
          ))}
        </div>
      </fieldset>

      <div className="form-actions">
        <button className="primary-button" type="submit" disabled={!canSubmit}>
          {isSubmitting ? 'Submitting...' : 'Join the waitlist'}
        </button>
        <p className="form-note">Your information is used only for OpenGent early access updates.</p>
      </div>

      {error ? <p className="form-message error">{error}</p> : null}
      {success ? <p className="form-message success">{success}</p> : null}
    </form>
  );
}
