import { Router } from 'express';
import { Prisma } from '@prisma/client';
import { leadSchema } from '@opengent/shared';
import { prisma } from '../lib/prisma.js';

const router = Router();

router.post('/', async (req, res) => {
  const parsed = leadSchema.safeParse(req.body);

  if (!parsed.success) {
    return res.status(400).json({
      message: 'Please complete all required fields.',
      errors: parsed.error.flatten()
    });
  }

  const payload = parsed.data;

  try {
    const lead = await prisma.lead.create({
      data: {
        name: payload.name.trim(),
        email: payload.email.trim().toLowerCase(),
        company: payload.company.trim(),
        role: payload.role,
        challenges: payload.challenges,
        tools: payload.tools
      }
    });

    return res.status(201).json({
      message: 'You are on the list.',
      id: lead.id
    });
  } catch (error) {
    if (
      error instanceof Prisma.PrismaClientKnownRequestError &&
      error.code === 'P2002'
    ) {
      return res.status(409).json({
        message: 'This email is already registered.'
      });
    }

    console.error(error);
    return res.status(500).json({
      message: 'Something went wrong while saving your request.'
    });
  }
});

export { router as leadsRouter };
