# OpenGent landing page

Production-minded landing page for OpenGent with a React + TypeScript frontend, Express + TypeScript backend, Prisma ORM, and PostgreSQL lead capture.

## Stack

- **Frontend:** React, TypeScript, Vite
- **Backend:** Node.js, Express, TypeScript
- **Database:** PostgreSQL via Prisma
- **Validation:** Zod on both client and server
- **Styling:** Custom CSS with dark navy base and blue/purple gradients

## Why this architecture

### 1. Vite + React instead of a heavier framework
The site is a marketing page with one conversion flow. Vite keeps the app fast to iterate on, easy to deploy, and simple to maintain.

### 2. Express API separated from the frontend
Lead capture is the only server requirement today, but a dedicated API gives OpenGent a clean seam for future additions like waitlist scoring, CRM syncs, admin dashboards, and authentication.

### 3. Prisma + PostgreSQL for lead storage
Postgres is durable, portable, and production-friendly. Prisma speeds up development while preserving schema discipline and migrations.

### 4. Shared validation schema
The lead form schema lives in `packages/shared` so the frontend and backend agree on payload shape and validation rules.

## What is included

- Polished landing page with:
  - hero section
  - problem/solution/value sections
  - lead form with CTA
  - company logo usage
  - dark navy design with purple/blue gradients
- API endpoint to store waitlist leads in Postgres
- Prisma schema for `Lead`
- Example environment files
- Basic production best practices

## Major development decisions

### Lead form fields
The form collects only the information needed for early-stage qualification:
- Name
- Email
- Company
- Role
- Data challenges
- Data stack tools

This keeps the friction low while still giving OpenGent enough data to segment leads.

### API validation and hygiene
The backend validates all lead submissions with Zod and normalizes list-style fields before writing to the database.

### Duplicate lead protection
`email` is unique in the database to prevent duplicate submissions.

### Deployment readiness
This repo is structured for independent frontend/backend deployment or containerization later.

## Basic production best practices included

- shared runtime validation
- unique email constraint
- HTTP security middleware with `helmet`
- CORS allowlist support via env var
- lightweight API rate limiting
- environment-based configuration
- graceful error handling

## Outside-scope decisions documented

The following were intentionally left outside scope to keep the MVP lean:

- CRM sync to HubSpot/Mailchimp
- double opt-in email workflows
- analytics pixels
- CAPTCHA or bot scoring
- admin dashboard
- auth / team management
- automated outbound sequences
- containerization / IaC
- end-to-end tests

These are natural next steps after initial lead validation.

## Local development

### 1. Install dependencies

```bash
npm install
```

### 2. Configure environment variables

Copy the example env files and update them:

```bash
cp apps/api/.env.example apps/api/.env
cp apps/web/.env.example apps/web/.env
```

### 3. Start Postgres
Use any local Postgres instance. Example connection string format:

```bash
postgresql://postgres:postgres@localhost:5432/opengent
```

### 4. Run Prisma migration

```bash
npm --workspace @opengent/api run prisma:generate
npm --workspace @opengent/api run prisma:migrate
```

### 5. Start the API and frontend

```bash
npm run dev:api
npm run dev:web
```

Frontend defaults to `http://localhost:5173` and backend to `http://localhost:8080`.

## Project structure

```text
apps/
  api/     Express + Prisma API
  web/     React landing page
packages/
  shared/  Shared validation schema and types
```

## Suggested next improvements

1. Add email confirmation and double opt-in
2. Sync qualified leads into CRM
3. Add analytics events for CTA and form conversion
4. Add transactional email notifications to founder inbox
5. Add case-study or proof section once customer discovery matures
