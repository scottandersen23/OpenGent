CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS leads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  company TEXT,
  role TEXT,
  challenge TEXT,
  stack TEXT,
  referrer TEXT,
  "createdAt" TIMESTAMP NOT NULL DEFAULT NOW()
);
