import cors from "cors";
import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { config } from "./config.js";
import { prisma } from "./prisma.js";
import { createLeadSchema } from "./validation.js";

const app = express();

app.use(helmet());
app.use(cors({ origin: config.allowedOrigin }));
app.use(express.json());

app.use(
  "/api",
  rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 100,
    standardHeaders: true,
    legacyHeaders: false
  })
);

app.get("/api/health", (_req, res) => {
  res.json({ ok: true });
});

app.post("/api/lead", async (req, res) => {
  const parsed = createLeadSchema.safeParse(req.body);

  if (!parsed.success) {
    return res.status(400).json({
      error: "Invalid submission",
      issues: parsed.error.flatten()
    });
  }

  const data = parsed.data;

  try {
    const lead = await prisma.lead.create({
      data: {
        name: data.name,
        email: data.email,
        company: data.company || null,
        role: data.role || null,
        challenge: data.challenge || null,
        stack: data.stack || null,
        referrer: data.referrer || "direct"
      }
    });

    return res.status(201).json({ success: true, id: lead.id });
  } catch (error) {
    console.error("Failed to create lead", error);
    return res.status(500).json({ error: "Failed to save lead" });
  }
});

app.listen(config.port, () => {
  console.log(`OpenGent API running on port ${config.port}`);
});
