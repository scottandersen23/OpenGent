import { z } from "zod";

export const roles = [
  "Founder / CEO",
  "CTO / VP Engineering",
  "Head of Data / Analytics",
  "Data Engineer / Analyst",
  "Other"
] as const;

export const challenges = [
  "Broken or unreliable data pipelines",
  "Metrics that do not match across dashboards",
  "Data quality issues",
  "Slow or reactive reporting",
  "We want better monitoring for our data stack",
  "Other"
] as const;

export const stacks = [
  "Snowflake",
  "BigQuery",
  "dbt",
  "Airflow",
  "Fivetran",
  "Postgres",
  "Other"
] as const;

export const createLeadSchema = z.object({
  name: z.string().min(2).max(100),
  email: z.string().email().max(255),
  company: z.string().max(100).optional().or(z.literal("")),
  role: z.enum(roles).optional().or(z.literal("")),
  challenge: z.enum(challenges).optional().or(z.literal("")),
  stack: z.enum(stacks).optional().or(z.literal("")),
  referrer: z.string().max(100).optional().default("direct")
});

export type CreateLeadInput = z.infer<typeof createLeadSchema>;
