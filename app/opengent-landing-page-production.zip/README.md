# OpenGent Landing Page — Production Stack

Production-oriented landing page for OpenGent AI Corp, built to capture and qualify early-access leads.

## Stack

- **Frontend:** React, TypeScript, Vite
- **Backend:** Node.js, Express, TypeScript
- **Database:** PostgreSQL
- **ORM:** Prisma
- **Deployment:** Docker, GitHub Actions, Vercel-ready frontend, Render/Fly/Railway-ready backend

## Major Development Decisions

### 1. Static marketing site + lightweight API
The landing page is intentionally simple and fast. The frontend stays focused on conversion and the backend only handles lead capture and validation.

### 2. Postgres-backed lead storage
Leads are written directly to Postgres to keep ownership of customer data, support segmentation later, and avoid coupling the MVP to an external CRM.

### 3. Shared validation contract
The frontend and backend use the same field constraints and enumerated options to reduce bad submissions and prevent drift.

### 4. Progressive-disclosure form
Only the highest-friction fields are optional. This keeps the first conversion step easy while still capturing useful lead context.

### 5. Referrer tracking
The app stores a hidden `referrer` value based on `?ref=` query params so you can attribute leads by acquisition channel immediately.

### 6. Production safeguards added
This version includes:
- server-side validation
- API rate limiting
- security headers
- Prisma migrations
- environment variable templates
- Dockerfiles
- GitHub Actions CI
- deployment notes

## Conversion Improvements Included

1. **Clear hero promise**
2. **Problem → solution story**
3. **Progressive form fields**
4. **Success state after submission**
5. **Referrer attribution**

## Local Development

### Option 1: Docker
```bash
docker compose up --build
```

Frontend: `http://localhost:5173`  
Backend: `http://localhost:4000`

### Option 2: Run manually

Backend:
```bash
cd backend
cp .env.example .env
npm install
npx prisma migrate dev
npm run dev
```

Frontend:
```bash
cd frontend
cp .env.example .env
npm install
npm run dev
```

## Database

Main model: `Lead`

Fields:
- `name`
- `email`
- `company`
- `role`
- `challenge`
- `stack`
- `referrer`
- `createdAt`

## Production Deployment Recommendation

### Frontend
Deploy to **Vercel**.

Why:
- simple static hosting
- fast CDN
- easy custom domain + SSL
- strong React/Vite support

### Backend
Deploy to **Render**, **Fly.io**, or **Railway**.

Why:
- easy Docker/Node deployments
- environment variable management
- Postgres support
- straightforward SSL and API hosting

### Database
Use managed **Postgres**:
- Neon
- Supabase
- Railway Postgres
- Render Postgres

## Suggested Production Topology

- `www.opengent.ai` → frontend
- `api.opengent.ai` → backend
- managed Postgres instance
- `ALLOWED_ORIGIN=https://www.opengent.ai`
- `VITE_API_BASE_URL=https://api.opengent.ai`

## Outside Scope / Next Steps

Intentionally left out of this MVP:
- admin dashboard
- CRM sync
- transactional email workflows
- analytics dashboards
- A/B testing engine
- user authentication

Recommended next additions:
1. Plausible or PostHog analytics
2. Resend/Postmark email notification for each lead
3. spam protection with hCaptcha or Cloudflare Turnstile
4. CRM sync to HubSpot or ConvertKit
5. lead scoring

## Security Notes

Before production launch:
- rotate all default secrets
- restrict `ALLOWED_ORIGIN`
- use managed Postgres with SSL
- add captcha if spam appears
- configure backup policy for the DB

## Form Field Strategy

Role, challenge, and stack options are intentionally static in code for the MVP. This is the right tradeoff for speed, validation simplicity, and low operational overhead. Move them to the DB/admin layer later only if marketing needs experimentation.

## Query Parameter Examples

```text
https://www.opengent.ai/?ref=linkedin
https://www.opengent.ai/?ref=twitter
https://www.opengent.ai/?ref=newsletter
```
