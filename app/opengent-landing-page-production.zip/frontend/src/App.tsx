import { FormEvent, useEffect, useMemo, useState } from "react";
import { challenges, roles, stacks } from "./types";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:4000";

type SubmissionState = "idle" | "loading" | "success" | "error";

function App() {
  const [showMore, setShowMore] = useState(false);
  const [referrer, setReferrer] = useState("direct");
  const [status, setStatus] = useState<SubmissionState>("idle");
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const ref = params.get("ref");
    if (ref) setReferrer(ref);
  }, []);

  const formId = useMemo(() => "signup", []);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus("loading");
    setErrorMessage("");

    const formData = new FormData(event.currentTarget);

    const payload = {
      name: String(formData.get("name") || ""),
      email: String(formData.get("email") || ""),
      company: String(formData.get("company") || ""),
      role: String(formData.get("role") || ""),
      challenge: String(formData.get("challenge") || ""),
      stack: String(formData.get("stack") || ""),
      referrer
    };

    try {
      const response = await fetch(`${API_BASE_URL}/api/lead`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        throw new Error("Submission failed");
      }

      setStatus("success");
      event.currentTarget.reset();
    } catch (error) {
      console.error(error);
      setStatus("error");
      setErrorMessage("We could not save your request. Please try again.");
    }
  }

  return (
    <div className="page-shell">
      <header className="site-header">
        <div className="brand">
          <img src="/logo.png" alt="OpenGent logo" className="logo" />
          <span className="brand-name">OpenGent</span>
        </div>
        <button
          className="ghost-button"
          onClick={() => document.getElementById(formId)?.scrollIntoView({ behavior: "smooth" })}
        >
          Join waitlist
        </button>
      </header>

      <main className="container">
        <section className="hero">
          <div className="hero-copy">
            <div className="eyebrow">Autonomous intelligence for modern data systems</div>
            <h1>AI agents that monitor data pipelines before issues impact business metrics.</h1>
            <p className="hero-text">
              OpenGent helps SaaS teams catch broken pipelines, drifting metrics, and hidden anomalies
              before they create reporting chaos or slow key decisions.
            </p>

            <div className="hero-actions">
              <button
                className="primary-button"
                onClick={() => document.getElementById(formId)?.scrollIntoView({ behavior: "smooth" })}
              >
                Get early access
              </button>
              <div className="micro-proof">Built for SaaS operators, analytics teams, and technical founders.</div>
            </div>
          </div>

          <div className="hero-panel">
            <div className="panel-card">
              <div className="panel-badge">What OpenGent monitors</div>
              <ul className="signal-list">
                <li>Pipeline freshness and ingestion failures</li>
                <li>Metric drift across dashboards</li>
                <li>Revenue and event anomalies</li>
                <li>Critical business signals in real time</li>
              </ul>
            </div>
          </div>
        </section>

        <section className="problem-solution-grid">
          <article className="card">
            <h2>Why this matters</h2>
            <p>
              Modern SaaS companies run on dashboards, but the systems behind those numbers fail quietly.
            </p>
            <ul className="feature-list">
              <li>Broken pipelines corrupt dashboards</li>
              <li>Revenue anomalies go unnoticed</li>
              <li>Teams burn hours debugging metrics</li>
            </ul>
          </article>

          <article className="card">
            <h2>How OpenGent helps</h2>
            <p>
              OpenGent deploys AI agents that continuously monitor the data stack and alert teams before
              issues disrupt reporting or decision-making.
            </p>
            <ul className="feature-list">
              <li>Continuous pipeline monitoring</li>
              <li>Business-context anomaly detection</li>
              <li>Fast, decision-ready alerts</li>
            </ul>
          </article>
        </section>

        <section className="form-section card" id={formId}>
          <div className="form-copy">
            <div className="eyebrow">Early access</div>
            <h2>Get early access to OpenGent</h2>
            <p>
              Join the waitlist to hear when the product opens for pilot customers and early design
              partners.
            </p>
          </div>

          {status === "success" ? (
            <div className="success-box">
              <h3>You’re on the list.</h3>
              <p>We’ll notify you when early access opens.</p>
            </div>
          ) : (
            <form className="lead-form" onSubmit={handleSubmit}>
              <input type="hidden" name="referrer" value={referrer} />

              <label>
                <span>Name</span>
                <input name="name" placeholder="Jane Doe" required />
              </label>

              <label>
                <span>Email</span>
                <input name="email" type="email" placeholder="jane@company.com" required />
              </label>

              <label>
                <span>Company</span>
                <input name="company" placeholder="Acme SaaS" />
              </label>

              {!showMore ? (
                <button type="button" className="secondary-button" onClick={() => setShowMore(true)}>
                  Add details (optional)
                </button>
              ) : (
                <div className="optional-grid">
                  <label>
                    <span>What best describes your role?</span>
                    <select name="role" defaultValue="">
                      <option value="">Select role</option>
                      {roles.map((role) => (
                        <option key={role} value={role}>
                          {role}
                        </option>
                      ))}
                    </select>
                  </label>

                  <label>
                    <span>What data challenges are you currently facing?</span>
                    <select name="challenge" defaultValue="">
                      <option value="">Select challenge</option>
                      {challenges.map((challenge) => (
                        <option key={challenge} value={challenge}>
                          {challenge}
                        </option>
                      ))}
                    </select>
                  </label>

                  <label>
                    <span>What tools are in your data stack?</span>
                    <select name="stack" defaultValue="">
                      <option value="">Select tool</option>
                      {stacks.map((stack) => (
                        <option key={stack} value={stack}>
                          {stack}
                        </option>
                      ))}
                    </select>
                  </label>
                </div>
              )}

              <button type="submit" className="primary-button" disabled={status === "loading"}>
                {status === "loading" ? "Submitting..." : "Join early access"}
              </button>

              {status === "error" && <p className="error-text">{errorMessage}</p>}
            </form>
          )}
        </section>
      </main>

      <footer className="site-footer">
        <span>© OpenGent AI Corp</span>
        <span>Referrer tracked as: {referrer}</span>
      </footer>
    </div>
  );
}

export default App;
