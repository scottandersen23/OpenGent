export const roles = [
  "Founder / CEO",
  "CTO / VP Engineering",
  "Head of Data / Analytics",
  "Data Engineer / Analyst",
  "Other"
] as const;

export const challenges = [
  "Broken or unreliable data pipelines",
  "Metrics that do not match across dashboards",
  "Data quality issues",
  "Slow or reactive reporting",
  "We want better monitoring for our data stack",
  "Other"
] as const;

export const stacks = [
  "Snowflake",
  "BigQuery",
  "dbt",
  "Airflow",
  "Fivetran",
  "Postgres",
  "Other"
] as const;

export type Role = (typeof roles)[number];
export type Challenge = (typeof challenges)[number];
export type Stack = (typeof stacks)[number];
