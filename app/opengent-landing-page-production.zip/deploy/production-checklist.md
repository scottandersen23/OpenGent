# Production Launch Checklist

## Infra
- [ ] Create managed Postgres database
- [ ] Set `DATABASE_URL`
- [ ] Set `ALLOWED_ORIGIN=https://www.opengent.ai`
- [ ] Set `VITE_API_BASE_URL=https://api.opengent.ai`

## Backend
- [ ] Deploy backend container
- [ ] Run `npx prisma migrate deploy`
- [ ] Verify `/api/health`
- [ ] Enable logs and restart policy

## Frontend
- [ ] Deploy to Vercel or equivalent
- [ ] Add custom domain
- [ ] Enable SSL
- [ ] Validate form POST to API domain

## Security
- [ ] Replace all default secrets
- [ ] Confirm CORS origin
- [ ] Add captcha if spam starts
- [ ] Confirm DB backups

## QA
- [ ] Submit a real lead
- [ ] Confirm lead stored in Postgres
- [ ] Confirm `referrer` saved correctly
- [ ] Test mobile layout
